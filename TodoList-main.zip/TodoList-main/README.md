# Todo List
It is a to-do list application made with C# Windows Form. In addition, features such as counter and calendar have been added.
<br>
<a href="https://github.com/furkankapukayaa/Todo-List/tree/main/ToDo%20Setup">Application Setup</a>
<br>

[![SourceCode](https://img.shields.io/badge/Source%20Code-click-red)](https://github.com/furkankapukayaa/Todo-List/tree/main/ToDo)
[![Screenshot](https://img.shields.io/badge/Screenshot-click-red)](https://github.com/furkankapukayaa/Todo-List/blob/main/SS/Screenshot_1.png)
[![Screenshot](https://img.shields.io/badge/Screenshot-click-red)](https://github.com/furkankapukayaa/Todo-List/blob/main/SS/Screenshot_2.png)
